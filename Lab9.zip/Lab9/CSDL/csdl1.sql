create database csdl1;
use csdl1;
DROP TABLE IF EXISTS NamePass;
create table NamePass
(
	NAME Nchar(20),
    PASS nchar(10)
);
insert into NamePass values('1','1');
select * from NamePass;
