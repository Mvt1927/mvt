/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author DELL
 */
import java.sql.*;
public class Connect {
    Connection con;
    public static Connection connecrDb( String acc, String pass,String localhost){
        try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con= DriverManager.getConnection("jdbc:mysql://localhost:"+localhost+"/csdl1",acc,pass);
                return con;
            }
            catch(Exception e1){
                try{
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection con= DriverManager.getConnection("jdbc:sqlserver://localhost:"+localhost+";databaseName=csdl1;user="+acc+";password="+pass);
                //may em ko cai dc SQLServer nen el chi co the lam nhu the nay thoi a //
                return con;
                }
                catch(Exception e2){
                    System.out.println("Khong the ket noi den csdl1");
                    System.exit(0);
                    return null;
            }
        }
    }
}
